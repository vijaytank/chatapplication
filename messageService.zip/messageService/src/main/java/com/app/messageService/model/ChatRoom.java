package com.app.messageService.model;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
public class ChatRoom {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NonNull
    private String roomName;
    @ManyToOne
    private User creator;
    @ManyToMany
    private Set<User> users = new HashSet<>();
    private LocalDateTime createdAt;

    // Getters and setters
}