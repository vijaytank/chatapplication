package com.app.messageService.controller;

import com.app.messageService.model.ChatRoom;
import com.app.messageService.model.Message;
import com.app.messageService.model.User;
import com.app.messageService.service.ChatRoomService;
import com.app.messageService.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.List;

@RestController
@RequestMapping("/api/chatrooms")
public class ChatRoomController {
    @Autowired
    private ChatRoomService chatRoomService;
    @Autowired
    UserService userService;

    @PostMapping
    public ResponseEntity<String> createChatRoom(@RequestBody @Validated ChatRoom chatRoom) {
        if (!chatRoomService.isChatRoomNameUnique(chatRoom.getRoomName())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Chat room with the same name already exists");
        }

        ChatRoom createdChatRoom = chatRoomService.createChatRoom(chatRoom, chatRoom.getCreator().getUsername());

        if (createdChatRoom != null) {
            return ResponseEntity.ok("Chat room created with ID: " + createdChatRoom.getId());
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create chat room");
        }
    }

    @PostMapping("/{chatRoomId}/join")
    public ResponseEntity<String> joinChatRoom(@PathVariable Long chatRoomId) {
        User user = getCurrentUser(); // Implement a method to get the currently logged-in user.
        ChatRoom chatRoom = chatRoomService.joinChatRoom(chatRoomId, user);
        if (chatRoom != null) {
            return ResponseEntity.ok("Joined chat room: " + chatRoom.getRoomName());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to join chat room");
        }
    }

    @PostMapping("/{chatRoomId}/send")
    public ResponseEntity<String> sendMessageToChatRoom(
            @PathVariable Long chatRoomId,
            @RequestBody @Validated Message message
    ) {
        User sender = getCurrentUser(); // Implement a method to get the currently logged-in user.

        if (sender == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not authenticated");
        }

        ChatRoom chatRoom = chatRoomService.getChatRoomById(chatRoomId);

        if (chatRoom == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Chat room not found");
        }

        chatRoomService.sendMessage(chatRoom, sender, message.getContent());

        return ResponseEntity.ok("Message sent to chat room: " + chatRoom.getRoomName());
    }

    @GetMapping("/{chatRoomId}/messages")
    public ResponseEntity<List<Message>> getChatRoomMessages(@PathVariable Long chatRoomId) {
        ChatRoom chatRoom = chatRoomService.getChatRoomById(chatRoomId);

        if (chatRoom == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        List<Message> messages = chatRoomService.getChatRoomMessages(chatRoom);
        return ResponseEntity.ok(messages);
    }

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            String username = userDetails.getUsername();

            return userService.findUserByUsername(username); // Implement the UserService method to find the user by username.
        }

        return null; // No authenticated user found.
    }
}
