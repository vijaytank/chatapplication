package com.app.messageService.service;

import com.app.messageService.exception.UserNotFoundException;
import com.app.messageService.model.ChatRoom;
import com.app.messageService.model.Message;
import com.app.messageService.model.User;
import com.app.messageService.repository.ChatRoomRepository;
import com.app.messageService.repository.MessageRepository;
import com.app.messageService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ChatRoomService {
    @Autowired
    private ChatRoomRepository chatRoomRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MessageRepository messageRepository;

    public ChatRoom createChatRoom(ChatRoom chatRoom, String creatorUsername) {
        User creator = userRepository.findByUsername(creatorUsername);
        if (creator == null) {
            throw new UserNotFoundException("Creator not found");
        }

        chatRoom.setCreator(creator);

        chatRoom.getUsers().add(creator);

        return chatRoomRepository.save(chatRoom);
    }

    public List<ChatRoom> getAllChatRooms() {
        return chatRoomRepository.findAll();
    }

    public boolean isChatRoomNameUnique(String roomName) {
        return chatRoomRepository.findByRoomName(roomName) == null;
    }

    public ChatRoom joinChatRoom(Long chatRoomId, User user) {
        Optional<ChatRoom> optionalChatRoom = chatRoomRepository.findById(chatRoomId);

        if (optionalChatRoom.isPresent()) {
            ChatRoom chatRoom = optionalChatRoom.get();
            chatRoom.getUsers().add(user);
            return chatRoomRepository.save(chatRoom);
        } else {
            return null; // Chat room not found
        }
    }

    public void sendMessage(ChatRoom chatRoom, User sender, String content) {
        Message message = new Message();
        message.setSender(sender);
        message.setChatRoom(chatRoom);
        message.setContent(content);

        // You may want to add additional logic, such as validation and security checks.

        messageRepository.save(message);
    }

    public List<Message> getChatRoomMessages(ChatRoom chatRoom) {
        return messageRepository.findByChatRoomOrderByTimestamp(chatRoom);
    }

    public ChatRoom getChatRoomById(Long chatRoomId) {
        Optional<ChatRoom> optionalChatRoom = chatRoomRepository.findById(chatRoomId);
        return optionalChatRoom.orElse(null);
    }
}

