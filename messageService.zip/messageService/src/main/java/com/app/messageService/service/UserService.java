package com.app.messageService.service;

import com.app.messageService.model.User;
import com.app.messageService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    public User findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public boolean authenticateUser(String username, String password) {
        User user = userRepository.findByUsername(username);

        if (user == null) {
            return false;
        }

        return passwordMatches(user.getPassword(), password);
    }

    private boolean passwordMatches(String storedHashedPassword, String providedPassword) {
        return storedHashedPassword.equals(providedPassword);
    }
}
